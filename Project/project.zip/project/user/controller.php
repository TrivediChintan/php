<?php
include("model.php");


class controller extends model
{
    function __construct()
    {
        session_start();
        model::__construct();
        $removeExtention = $_SERVER['PATH_INFO'];
        $cate_arr = $this->select("category");
        switch ($removeExtention) {
            case '/index':
                include "index.php";
                break;
            case '/about':
                include "about.php";
                break;
                // case '/products':
                //     include "products.php";
                //     break;
            case '/single-product':
                if (isset($_REQUEST['single_pro_id'])) {
                    $single_prod_id = $_REQUEST['single_pro_id'];
                    $where = array("prod_id_fk" => $single_prod_id);
                    $single_prod_arr = $this->select_where_multidata('single_product', $where);
                }
                include "single-product.php";
                break;

            case '/only-single-product':
                if (isset($_REQUEST['single_pro_id'])) {
                    $single_prod_id = $_REQUEST['single_pro_id'];
                    $where = array("single_prod_id" => $single_prod_id);
                    $single_prod_arr = $this->select_where_multidata('single_product', $where);
                }
                include "only-single-product.php";
                break;
            case '/contact':
                include "contact.php";
                break;

            case '/login':
                if (isset($_POST['ulogin'])) {
                    $username = $_POST['uname'];
                    $userpass = $_POST['upassword'];



                    $where = array("u_username" => $username, "u_password" => $userpass);

                    $fetch_where = $this->select_where("users", $where);
                    $dbusername = $fetch_where->u_username;
                    $dbupassword = $fetch_where->u_password;
                    $dbuserid = $fetch_where->u_id;

                    $_SESSION["username"] = $dbusername;
                    $_SESSION["user"] = $dbuserid;

                    if ($dbusername == $username && $dbupassword == $userpass) {
                        echo "<script>
                    alert('Wlecome User')
                    window.location.href = 'index'
                    </script>";
                    } else {

                        echo "<script>
                    alert('Invalide Username Or Password')</script>";
                    }

                    if (isset(($_POST['uremember']))) {
                        setcookie('username', $username, time() + 30);
                        setcookie('userpassword', $userpass, time() + 30);
                    }
                }


                include "login.php";
                break;

            case "/logout":
                unset($_SESSION["username"]);
                unset($_SESSION["user"]);
                include "index.php";
                // header("location:index");
                break;
            case '/register':

                if (isset($_POST['register'])) {
                    $ufirtsname = $_POST['ufirtsname'];
                    $umiddelname = $_POST['umiddelname'];
                    $ulastname = $_POST['ulastname'];
                    $uusername = $_POST['uusername'];
                    $upassword = $_POST['upassword'];
                    $uemail = $_POST['uemail'];
                    $umobile = $_POST['umobile'];
                    $uaddress = $_POST['uaddress'];
                    $ugender = $_POST['ugender'];

                    $ulang = "";
                    $ulanguage = $_POST['ulang'];
                    foreach ($ulanguage as $ulang) {
                        $ulang = implode(",", $ulanguage);
                    }

                    $uimage = $_FILES['uimage']['name'];
                    $duplicateimage = $_FILES['uimage']['tmp_name'];
                    $path = "assets/user_images/" . $uimage;
                    move_uploaded_file($duplicateimage, $path);


                    $data = array('u_firstname' => $ufirtsname, 'u_middlename' => $umiddelname, 'u_lastname' => $ulastname, 'u_username' => $uusername, 'u_password' => $upassword, 'u_email' => $uemail, 'u_mobile' => $umobile, 'u_address' => $uaddress, 'u_gender' => $ugender, 'u_languages' => $ulang, 'u_image' => $uimage);


                    $this->insert("users", $data);
                }

                include "register.php";
                break;

            case "/subcategory":
                if (isset($_REQUEST['cate_id'])) {
                    $cate_id = $_REQUEST['cate_id'];
                    $where = array("cate_id_fk" => $cate_id);
                    $subcate_arr = $this->select_where_multidata('subcategory', $where);
                }
                include "subcategory.php";
                break;


            case "/product":
                if (isset($_REQUEST['subcate_id'])) {
                    $subcate_id = $_REQUEST['subcate_id'];
                    $where = array("subcate_id_fk" => $subcate_id);
                    $product_arr = $this->select_where_multidata('product', $where);
                }
                include "product.php";
                break;

            case "/addcart":
                if (isset($_SESSION["user"])) {
                    if (isset($_REQUEST['addcart_id'])) {
                        $qty = $_REQUEST['qty'];
                        $userid = $_SESSION["user"];
                        $single_id = $_REQUEST['single_id'];
                        // $prod_id = $_REQUEST['prod_id'];
                        
                        $where= array('u_id_fk'=>$userid,'single_prod_id_fk'=>$single_id);

                        $fetch_where = $this->select_where("cart", $where);

                        if(!empty($fetch_where) )
                        {
                            $dbqty = $fetch_where->quantity;
                            $totalqty=$qty+$dbqty;

                            $data = array("quantity" => $totalqty);
                            $run = $this->update('cart',$data,$where);
                            if ($run) {
                                echo "<script>
                        alert('Product Update Sucessfuly.....')
                        window.location.href= 'only-single-product?single_pro_id=$single_id'
                        </script>";
                            }
                        }
                        else{
                            $data = array("quantity" => $qty, "u_id_fk" => $userid, "single_prod_id_fk" => $single_id);
                            $run = $this->insert('cart', $data);
                            if ($run) {
                                echo "<script>
                        alert('Product Add Sucessfuly.....')
                        window.location.href= 'only-single-product?single_pro_id=$single_id'
                        </script>";
                            }
                        }


                   
                    }
                } else {
                    echo "<script>
                    alert('Please Login First.....')
                    window.location.href= 'login'
                    </script>";
                }

                include "only-single-product.php";
                break;

            case "/cart":
                if (isset($_SESSION["user"])) {
                    $uid = $_SESSION["user"];
                    $where = array('u_id_fk' => $uid);
                    $cart_arr = $this->select_join_where_multidata('cart', 'single_product', 'cart.single_prod_id_fk = single_product.single_prod_id', $where);







                    
                    
                    // $run = $this-> select('cart');
                    // $row_count= mysqli_num_rows($run);
                }

                include "cart.php";
                break;

                case "/delete-cart":
                    $delcrt = $_GET['delcrt'];
                    $where = array('cart_id' => $delcrt);
                    $delete = $this->delete_where('cart', $where);
                    if($delete)
                    {
                        echo "<script>
                        alert('deleted')
                        
                        </script>";
                    }
                    include "cart.php";
                    break;
            case "/confirm-cart":

                include "confirm-cart.php";
                break;

            case '/admin-login':
                include "../admin/index.php";
                break;
        }
    }
}

$obj = new controller();
