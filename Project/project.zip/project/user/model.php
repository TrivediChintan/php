<?php

class model
{
    public $con="";

    function __construct()
    {
        $this->con = new mysqli("localhost", "root", "", "ecomm");

        //   echo "work";exit();
    }

    function insert($tbl,$data)
    {
        $col_arr = array_keys($data);//table's col ex. id name email pass etc
        $col = implode(',',$col_arr);// with saperator id,name,email,pass etc

        $val_arr = array_values($data);//   /table's data without seprator 1 chinatn c@.com 123 etc....
        $val = implode("','",$val_arr);   //table's data 1,chinatn,c@.com,123 etc....

        $sql = "insert into $tbl ($col) values ('$val')";
        
        $run = $this->con->query($sql);

        return $run;

    }

    function select($tbl)
    {
        $sel = "select * from $tbl";
        $run = $this->con->query($sel);

        while ($fetch = $run->fetch_object()) {
            $arr[] = $fetch;
        }
        if (!empty($arr)) {
            return $arr;
        }
    }

    function select_where($tbl,$where)
    {
        $wcol_arr = array_keys($where);
        $wval_arr = array_values($where);

        $sel = "select * from $tbl where 1=1";


        $i=0;
        foreach($where as $w)
        {
            $sel .= " and $wcol_arr[$i] = '$wval_arr[$i]'";
            $i++;
        }
        $run = $this->con->query($sel);
        $fetch_where = $run->fetch_object(); 
        return $fetch_where;
    }


    function select_where_multidata($tbl,$where)
    {
        $wcol_arr = array_keys($where);
        $wval_arr = array_values($where);

        $sel = "select * from $tbl where 1=1";


        $i=0;
        foreach($where as $w)
        {
            $sel .= " and $wcol_arr[$i] = '$wval_arr[$i]'";
            $i++;
        }
        // echo $sel;exit();
        $run = $this->con->query($sel);
        while($fetch_where_multi = $run->fetch_object())
        {
            $arr[] = $fetch_where_multi;
        } 
        if(!empty($arr))
        {
            return $arr;
        }
    }


    function select_join_where_multidata($tbl1,$tbl2,$on,$where)
    {
        $sele="select * from $tbl1 join $tbl2 on $on where 1=1";
        $col_arr = array_keys($where);
        $val_arr = array_values($where);

        $i=0;
        
        foreach($where as $w)
        {
            $sele.=" and $col_arr[$i] = '$val_arr[$i]'";
            $i++;
        }
        // echo $sele;exit();
        $run = $this->con->query($sele);

        while($fetch=$run->fetch_object())
        {
            $arr[]=$fetch;
        }
        if(!empty($arr))
        {
            return $arr;
        }

    }

    function delete_where($tbl,$where)
    {
        $wcol_arr = array_keys($where);
        $wval_arr = array_values($where);

        $del= "delete from $tbl where 1=1";

        $k=0;
        foreach($where as $w)
        {
            $del.= " and $wcol_arr[$k] = '$wval_arr[$k]'";
            $k++;
        }
        // echo $del;exit;
        $run = $this->con->query($del);
        
        return $run;

    }


    function update($tbl,$data,$where)
    {
        $col_arr = array_keys($data);
        $val_arr = array_values($data);

        $update = "update $tbl set ";

        $count = count($data);
        
        $j=0;
        foreach($data as $d)
        {
            if($count == $j+1)
            {
                $update.= "$col_arr[$j] = '$val_arr[$j]'";
            }
            else
            {
                $update.= "$col_arr[$j] = '$val_arr[$j]', ";
                $j++;
            }
        }

        $wcol_arr = array_keys($where);
        $wval_arr = array_values($where);

        $update.= " where 1=1";

        $i=0;
        foreach($where as $w)
        {
            $update.= " and $wcol_arr[$i] = '$wval_arr[$i]'";
            $i++;
        }
        $update_data = $this->con->query($update);


        return $update_data;
    }

}