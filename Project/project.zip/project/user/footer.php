<footer>
    <div class="container">
        <div class="row">
            <div class="col-lg-3">
                <div class="first-item">
                    <div class="logo">
                        <img src="assets/images/white-logo.png" alt="hexashop ecommerce templatemo">
                    </div>
                    <ul>
                        <li><a href="#">16501 Collins Ave, Sunny Isles Beach, FL 33160, United States</a></li>
                        <li><a href="#">hexashop@company.com</a></li>
                        <li><a href="#">010-020-0340</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-3">
                <h4>Shopping &amp; Categories</h4>
                <ul>
                    <li><a href="#">Men’s Shopping</a></li>
                    <li><a href="#">Women’s Shopping</a></li>
                    <li><a href="#">Kid's Shopping</a></li>
                </ul>
            </div>
            <div class="col-lg-3">
                <h4>Useful Links</h4>
                <ul>
                    <li><a href="index.php">Homepage</a></li>
                    <li><a href="about.php">About Us</a></li>
                    <li><a href="#">Help</a></li>
                    <li><a href="contact.php">Contact Us</a></li>
                </ul>
            </div>
            <div class="col-lg-3">
                <h4>Help &amp; Information</h4>
                <ul>
                    <li><a href="#">Help</a></li>
                    <li><a href="#">FAQ's</a></li>
                    <li><a href="#">Shipping</a></li>
                    <li><a href="#">Tracking ID</a></li>
                </ul>
            </div>
            <div class="col-lg-12">
                <div class="under-footer">
                    <p>Copyright © 2024 HexaShop Co., Ltd. All Rights Reserved.

                        <br>Design: <a href="https://templatemo.com" target="_parent" title="free css templates">Chintan Trivedi</a>
                    </p>
                    <ul>
                        <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                        <li><a href="#"><i class="fa fa-behance"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</footer>


<!-- jQuery -->
<script src="assets/js/jquery-2.1.0.min.js"></script>

<!-- Bootstrap -->
<script src="assets/js/popper.js"></script>
<script src="assets/js/bootstrap.min.js"></script>

<!-- Plugins -->
<script src="assets/js/owl-carousel.js"></script>
<script src="assets/js/accordions.js"></script>
<script src="assets/js/datepicker.js"></script>
<script src="assets/js/scrollreveal.min.js"></script>
<script src="assets/js/waypoints.min.js"></script>
<script src="assets/js/jquery.counterup.min.js"></script>
<script src="assets/js/imgfix.min.js"></script>
<script src="assets/js/slick.js"></script>
<script src="assets/js/lightbox.js"></script>
<script src="assets/js/isotope.js"></script>

<!-- Global Init -->
<script src="assets/js/custom.js"></script>

<!-- cart js -->
<!-- <script src="assets/js/cart.js"></script> -->

<script>
    $(function() {
        var selectedClass = "";
        $("p").click(function() {
            selectedClass = $(this).attr("data-rel");
            $("#portfolio").fadeTo(50, 0.1);
            $("#portfolio div").not("." + selectedClass).fadeOut();
            setTimeout(function() {
                $("." + selectedClass).fadeIn();
                $("#portfolio").fadeTo(50, 1);
            }, 500);

        });
    });
</script>

<script>
    loginuname = document.getElementById("uname");
    loginupass = document.getElementById("upassword");
    loginusererr = document.getElementById("loginusererr");
    loginpasserr = document.getElementById("loginpasserr");



    function getLoginAlert()
    {
        if(loginuname.value == "")
        {
            loginusererr.innerHTML = "UserName Is Required";
            loginusererr.style.color = "red";
            // return false;
        }
        else 
        {
            loginusererr.innerHTML = "";
        }


        if(loginupass.value == "")
        {
            loginpasserr.innerHTML = "Password Is Required";
            loginpasserr.style.color = "red";
            return false;
        }
        else 
        {
            loginpasserr.innerHTML = "";
        }
    }




    reg = document.getElementById("form-submit");
    firstn = document.getElementById("firstname");
    middn = document.getElementById("middelname");
    lastn = document.getElementById("lastname");
    un = document.getElementById("username");
    pass = document.getElementById("password");
    cpass = document.getElementById("cpassword");
    email = document.getElementById("email");
    mn = document.getElementById("mobile");
    add = document.getElementById("address");
    gn1 = document.getElementById("gender1");
    gn = document.getElementsByName("ugender");
    gn1 = gn[0];
    gn2 = gn[1];
 
    ln = document.getElementsByName("ulang[]");
    ln1 = ln[0];
    ln2 = ln[1];
    ln3 = ln[2];
    ln4 = ln[3];
    img = document.getElementById("image");


    fnerr = document.getElementById("firstnerr");
    nmExp = /^[a-zA-Z]{2,10}$/;
    unerr = document.getElementById("unerr");
    unExp = /^[a-zA-Z0-9]{5,15}$/;
    passerr =document.getElementById("passerr");
    passExp = /^[a-zA-Z0-9]$/;
    cpasserr =document.getElementById("cpasserr");
   
    emailerr =document.getElementById("emailerr");
    emailExp = /^[a-zA-Z]+$/;


   
    moberr =document.getElementById("moberr");
    mnExp = /^[0-9]{10}$/;

    adderr =document.getElementById("adderr");
    addExp = /^[a-zA-Z]{10,40}$/;
    
    gnerr =document.getElementById("gnerr");
    lnerr =document.getElementById("lnerr");

    function getAlert() {
// ----------------------------------------------------------First Name - Mid Name - Last Name--------------------------------------------------------------------------
        if (firstn.value == "") {
            fnerr.innerHTML = "First Name Is Required";
            fnerr.style.color = "red";
            // return false;
        } else if (!nmExp.test(firstn.value)) {
            fnerr.innerHTML = "First Name must be 2 to 8 character only";
            fnerr.style.color = "red";
            // return false;
        } else if (middn.value == "") {
            fnerr.innerHTML = "Middel Name Is Required";
            fnerr.style.color = "red";
            // return false;
        } else if (!nmExp.test(middn.value)) {
            fnerr.innerHTML = "Middel Name must be 2 to 8 character only";
            fnerr.style.color = "red";
            // return false;
        } else if (lastn.value == "") {
            fnerr.innerHTML = "Last Name Is Required";
            fnerr.style.color = "red";
            // return false;
        } else if (!nmExp.test(lastn.value)) {
            fnerr.innerHTML = "Last Name must be 2 to 8 character only";
            fnerr.style.color = "red";
            // return false;
        } else {
            fnerr.innerHTML = "";
        }

// ----------------------------------------------------------User Name--------------------------------------------------------------------------

        if (un.value == "") {
            unerr.innerHTML = "UserName Is Required";
            unerr.style.color = "red";
            // return false;
        } 
        else if (!unExp.test(un.value)) {
            unerr.innerHTML = "UserName must be 5 to 10 character only";
            unerr.style.color = "red";
            // return false;
        }
         else {
            unerr.innerHTML = "";
        }
        
// --------------------------------------------------------Password--------------------------------------------------------------------------

        if (pass.value == "") {
            passerr.innerHTML = "Password Is Required";
            passerr.style.color = "red";
            // return false;
        }
        else {
            passerr.innerHTML = "";
        }

// -----------------------------------------------------Confirm Password--------------------------------------------------------------------------
        if (cpass.value == "") {
            cpasserr.innerHTML = "Confirm Password Is Required";
            cpasserr.style.color = "red";
            // return false;
        } 
        else if (cpass.value != pass.value) {
            cpasserr.innerHTML = "Confirm Paasword Dose Not Match";
            cpasserr.style.color = "red";
            // return false;
        } 
        else {
            cpasserr.innerHTML = "";
        }


// ----------------------------------------------------------email--------------------------------------------------------------------------
if (email.value == "") {
            emailerr.innerHTML = "Email Is Required";
            emailerr.style.color = "red";
            // return false;
        }
        else if (!emailExp.test(email.value)) {
            emailerr.innerHTML = "Enter Valid Email";
            emailerr.style.color = "red";
            // return false;
        }
        else {
            emailerr.innerHTML = "";
        }


// ----------------------------------------------------------Mobile--------------------------------------------------------------------------

        if (mn.value == "") {
            moberr.innerHTML = "Mobile Number Is Required";
            moberr.style.color = "red";
            // return false;
        } 
        else if (!mnExp.test(mn.value)) {
            moberr.innerHTML = "Enter Valid Mobile Number";
            moberr.style.color = "red";
            // return false;
        } 
        else {
            moberr.innerHTML = "";
        }

// ----------------------------------------------------------Address--------------------------------------------------------------------------

        if (add.value == "") {
            adderr.innerHTML = "Address Is Required";
            adderr.style.color = "red";
            // return false;
        }
        else if (!addExp.test(add.value)) {
            adderr.innerHTML = "Enter Valid Address";
            adderr.style.color = "red";
            // return false;
        } 
        else {
            adderr.innerHTML = "";
        }

// ----------------------------------------------------------Gender--------------------------------------------------------------------------

if (gn1.checked == false && gn2.checked == false) {
            gnerr.innerHTML = "Gender Is Required";
            gnerr.style.color = "red";
            // return false;
        }
        else {
            gnerr.innerHTML = "";
        }

// ----------------------------------------------------------Language--------------------------------------------------------------------------

if (ln1.checked == false && ln2.checked == false && ln3.checked == false && ln4.checked == false) {
            lnerr.innerHTML = "Language Is Required";
            lnerr.style.color = "red";
            // return false;
        }
        else {
            lnerr.innerHTML = "";
        }
// ----------------------------------------------------------Image--------------------------------------------------------------------------

if (img.value == "") {
            imgerr.innerHTML = "Image Is Required";
            imgerr.style.color = "red";
            return false;
        } else {
            imgerr.innerHTML = "";
        }


    }

    // console.log(firstn,firstn,lastn,un);
</script>

</body>

</html>