<?php
include('header.php');
?>
<!-- ***** Header Area End ***** -->

<!-- ***** Main Banner Area Start ***** -->
<div class="page-heading about-page-heading" id="top">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <div class="inner-content">
          <h2>Login Here</h2>
          <span>It's great connecting with you.</span>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- ***** Main Banner Area End ***** -->

<!-- ***** Register Area Starts ***** -->
<div class="contact-us">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-6">
        <div class="section-heading">
          <h2>Wellcome</h2>
          <span>Exciting times ahead: exclusive offers, insider tips, and much more, are all coming your way.</span></br>
          <span>If you have not registered, do it from <a href="register.php">Register Here</a></span>
        </div>
        <form id="contact" method="post" onsubmit="return getLoginAlert()">
          <div class="row">
            <div class="col-lg-12 my-2">
              <fieldset>
                <input name="uname" type="text" id="uname" placeholder="Enter Username" value="<?php if(isset($_COOKIE['username'])){echo $_COOKIE['username'];} ?>">
              </fieldset>
            </div>
            <div class="col-lg-12">
            <b id="loginusererr"></b>
            </div>
            <div class="col-lg-12 my-2">
              <fieldset>
                <input name="upassword" type="text" id="upassword" placeholder="Enter Password" value="<?php if(isset($_COOKIE['userpassword'])){echo $_COOKIE['userpassword'];} ?>">
              </fieldset>
            </div>
            <div class="col-lg-12">
            <b id="loginpasserr"></b>
            </div>
            <div class="col-lg-12 my-2">
              <div class="form-check form-check-inline">
                <input name="uremember" class="form-check-input" type="checkbox">
                <label class="form-check-label" for="inlineCheckbox1">RememberMe</label>
              </div>
            </div>
            <div class="col-lg-12 my-2">
              <fieldset>
                <button type="submit" name="ulogin" id="ulogin" class="main-dark-button"><i class="fa fa-sign-in"></i></button>
              </fieldset>
            </div>
        </form>
      </div>
    </div>
  </div>
</div>
<!-- ***** Register Area Ends ***** -->

<!-- ***** Footer Start ***** -->
<?php
include('footer.php');
?>