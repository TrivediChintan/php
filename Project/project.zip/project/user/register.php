<?php
include('header.php');
?>
<!-- ***** Header Area End ***** -->

<!-- ***** Main Banner Area Start ***** -->
<div class="page-heading about-page-heading" id="top">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <div class="inner-content">
          <h2>Register Here</h2>
          <span>Awesome, clean &amp; creative HTML5 Template</span>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- ***** Main Banner Area End ***** -->

<!-- ***** Register Area Starts ***** -->
<div class="contact-us">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-6">
        <div class="section-heading">
          <h2>Say Hello. Don't Be Shy!</h2>
          <span>Register Here to Hexashop different from the others.</span></br>
          <span>Already regiser ? <a href="login.php">Log in Here</a></span>
        </div>
        <form method="post" enctype="multipart/form-data" onsubmit="return getAlert()">
          <div class="row">
            <div class="col-lg-4 my-2">
              <fieldset>
                <input name="ufirtsname" type="text" id="firstname" placeholder="Enter First Name">
              </fieldset>
            </div>
            <div class="col-lg-4 my-2">
              <fieldset>
                <input name="umiddelname" type="text" id="middelname" placeholder="Enter Middel Name">
              </fieldset>
            </div>
            <div class="col-lg-4 my-2">
              <fieldset>
                <input name="ulastname" type="text" id="lastname" placeholder="Enter Last Name">
              </fieldset>
            </div>
            <div class="col-lg-12">
            <b id="firstnerr"></b>
            <b id="middelnerr"></b>
            <b id="lastnerr"></b>
            </div>
            <div class="col-lg-12 my-2">
              <fieldset>
                <input name="uusername" type="text" id="username" placeholder="Enter Username">
              </fieldset>
            </div>
            <div class="col-lg-12">
            <b id="unerr"></b>
            </div>
            <div class="col-lg-12 my-2">
              <fieldset>
                <input name="upassword" type="text" id="password" placeholder="Enter Password">
              </fieldset>
            </div>
            <div class="col-lg-12">
            <b id="passerr"></b>
            </div>
            <div class="col-lg-12 my-2">
              <fieldset>
                <input name="ucpassword" type="text" id="cpassword" placeholder="Confirm Your Password">
              </fieldset>
            </div>
            <div class="col-lg-12">
            <b id="cpasserr"></b>
            </div>
            <div class="col-lg-12 my-2">
              <fieldset>
                <input name="uemail" type="text" id="email" placeholder="Enter Your Email">
              </fieldset>
            </div>
            <div class="col-lg-12">
            <b id="emailerr"></b>
            </div>
            <div class="col-lg-12 my-2">
              <fieldset>
                <input name="umobile" type="text" id="mobile" placeholder="Enter Your Mobile Number">
              </fieldset>
            </div>
            <div class="col-lg-12">
            <b id="moberr"></b>
            </div>
            <div class="col-lg-12 my-2">
              <fieldset>
                <input name="uaddress" type="text" id="address" placeholder="Enter Your Address">
              </fieldset>
            </div>
            <div class="col-lg-12">
            <b id="adderr"></b>
            </div>
            <div class="col-lg-12 my-1">
              <label><b>Gender:</b></label>
            </div>
            <div class="col-lg-12 m-1">
              <div class="form-check form-check-inline">
                <input name="ugender" class="form-check-input" type="radio" id="gender1" value="Male">
                <label class="form-check-label" for="inlineRadio3">Male</label>
              </div>
              <div class="form-check form-check-inline">
                <input name="ugender" class="form-check-input" type="radio" id="gender2" value="Female">
                <label class="form-check-label" for="inlineRadio3">Female</label>
              </div>
              <div class="col-lg-12">
            <b id="gnerr"></b>
            </div>
            </div>
            <div class="col-lg-12">
              <label><b>Languages:</b></label>
            </div>
            <div class="col-lg-12 m-1">
              <div class="form-check form-check-inline">
                <input name ="ulang[]" class="form-check-input" type="checkbox" id="lang1" value="English">
                <label class="form-check-label" for="inlineCheckbox1">English</label>
              </div>
              <div class="form-check form-check-inline">
                <input name ="ulang[]" class="form-check-input" type="checkbox" id="lang2" value="Gujarat">
                <label class="form-check-label" for="inlineCheckbox2">Gujarat</label>
              </div>
              <div class="form-check form-check-inline">
                <input name ="ulang[]" class="form-check-input" type="checkbox" id="lang3" value="Hindi">
                <label class="form-check-label" for="inlineCheckbox1">Hindi</label>
              </div>
              <div class="form-check form-check-inline">
                <input name ="ulang[]" class="form-check-input" type="checkbox" id="lang4" value="Tamil">
                <label class="form-check-label" for="inlineCheckbox2">Tamil</label>
              </div>
              <div class="col-lg-12">
            <b id="lnerr"></b>
            </div>
            </div>
            <div class="col-lg-12 my-2">
              <fieldset>
                <label>Upload User Image</label>
                <input name="uimage" type="file" id="image" title="Upload Your Image">
              </fieldset>
            </div>
            <div class="col-lg-12">
            <b id="imgerr"></b>
            </div>
            <div class="col-lg-12 my-2">
              <fieldset>
                <button name="register" type="submit" id="form-submit" class="main-dark-button"><i class="fa fa-user-plus"></i></button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<!-- ***** Register Area Ends ***** -->

<!-- ***** Footer Start ***** -->
<?php
include('footer.php');
?>