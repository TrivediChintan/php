<?php
include ("header.php");
?>
<div class="main-panel">
    <div class="content-wrapper">
        <div class="page-header">
            <h3 class="page-title"> Add Product </h3>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="dashboard.php">Product</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Add Product</li>
                </ol>
            </nav>
        </div>
        <div class="row justify-content-center">
            <div class="col-md-6 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Add Product</h4>
                        <p class="card-description"> Insert Your Product Here. </p>
                        <form class="forms-sample">
                            <div class="row">
                                <div class="form-group col-sm-6">
                                    <label for="exampleInputUsername1">Select Category</label>
                                    <div class="col-sm-12">
                                        <select class="form-select">
                                            <option>Category1</option>
                                            <option>Category2</option>
                                            <option>Category3</option>
                                            <option>Category4</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group col-sm-6">
                                    <label for="exampleInputUsername1">Select Subcategory</label>
                                    <div class="col-sm-12">
                                        <select class="form-select">
                                            <option>Subcategory1</option>
                                            <option>Subcategory2</option>
                                            <option>Subcategory3</option>
                                            <option>Subcategory4</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputUsername1">Product Brand Name</label>
                                    <input type="text" class="form-control" id="exampleInputUsername1"
                                        placeholder="Enter Product Brand Name">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputUsername1">Product Name</label>
                                    <input type="text" class="form-control" id="exampleInputUsername2"
                                        placeholder="Enter Product Name">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputUsername1">Product Price</label>
                                    <input type="text" class="form-control" id="exampleInputUsername3"
                                        placeholder="Enter Product Price">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputUsername1">Upload Product Image</label>
                                    <input type="file" class="form-control" id="exampleInputUsername4"
                                        placeholder="Enter Product Image">
                                </div>
                                <button type="submit" class="btn btn-gradient-primary me-2">Add Product</button>
                                <button class="btn btn-light">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- content-wrapper ends -->
    <?php
    include ("footer.php");
    ?>