<?php
include("header.php");
?>
<div class="main-panel">
    <div class="content-wrapper">
        <div class="page-header">
            <h3 class="page-title"> Add Subcategory </h3>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Subcategory</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Add Subcategory</li>
                </ol>
            </nav>
        </div>
        <div class="row justify-content-center">
            <div class="col-md-6 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Add Subcategory</h4>
                        <p class="card-description"> Enter Your Subcategory Here. </p>
                        <form method="post" enctype="multipart/form-data" onsubmit="return getAlert()">
                            <div class="row">
                            <div class="form-group col-sm-12">
                                    <label for="exampleInputUsername1">Select Category</label>
                                    <div class="col-sm-12">
                                        <select class="form-select" id="cate">
                                            <option>Category1</option>
                                            <option>Category2</option>
                                            <option>Category3</option>
                                            <option>Category4</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputUsername1">Subcategory</label>
                                    <input name="subcategory" type="text" class="form-control" id="subcategory" placeholder="Enter Subcategory Name">
                                    <b id="unerr"></b>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputUsername1">Upload Subcategory Image</label>
                                    <input name="subcategory" type="file" class="form-control" id="subcategoryimage" placeholder="Enter Subcategory Image">
                                    <b id="imgerr"></b>
                                </div>
                                <button name="register" type="submit" class="btn btn-gradient-primary me-2" id="form-submit">Add Subcategory</button>
                                <button class="btn btn-light">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>


        </div>
    </div>
    <!-- content-wrapper ends -->
    <?php
    include("footer.php");
    ?>