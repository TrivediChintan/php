<?php
include("header.php");
?>
<div class="main-panel">
    <div class="content-wrapper">
        <div class="page-header">
            <h3 class="page-title"> Add Category </h3>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Category</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Add Category</li>
                </ol>
            </nav>
        </div>
        <div class="row justify-content-center">
            <div class="col-md-6 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Add Category</h4>
                        <p class="card-description"> Enter Your Category </p>
                        <form method="post" enctype="multipart/form-data" onsubmit="return getAlert()">
                            <div class="row">
                                <div class="form-group">
                                    <label for="exampleInputUsername1">Category</label>
                                    <input name="category" type="text" class="form-control" id="category" placeholder="Enter Category">
                                    <b id="unerr"></b>
                                </div>
                               
                                <button name="register" type="submit" class="btn btn-gradient-primary me-2" id="form-submit">Add Category</button>
                                <button class="btn btn-light">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>


        </div>
    </div>
    <!-- content-wrapper ends -->
    <?php
    include("footer.php");
    ?>