                <!-- partial:partials/_footer.html -->
                <footer class="footer">
                <div class="d-sm-flex justify-content-center justify-content-sm-between">
                    <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © 2023 <a
                    href="https://www.bootstrapdash.com/" target="_blank">BootstrapDash</a>. All rights reserved.</span>
                    <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Hand-crafted & made with <i
                    class="mdi mdi-heart text-danger"></i></span>
                    </div>
                </footer>
                <!-- partial -->
            </div>
            <!-- main-panel ends -->
        </div>
        <!-- page-body-wrapper ends -->
    </div>
<!-- container-scroller -->
<!-- plugins:js -->
<script src="assets/vendors/js/vendor.bundle.base.js"></script>
<!-- endinject -->
<!-- Plugin js for this page -->
<script src="assets/vendors/chart.js/chart.umd.js"></script>
<script src="assets/vendors/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
<script src="../../assets/vendors/select2/select2.min.js"></script>
<!-- End plugin js for this page -->
<!-- inject:js -->
<script src="assets/js/off-canvas.js"></script>
<script src="assets/js/misc.js"></script>
<script src="assets/js/settings.js"></script>
<script src="assets/js/todolist.js"></script>
<script src="assets/js/jquery.cookie.js"></script>
<!-- endinject -->
<!-- Custom js for this page -->
<script src="assets/js/dashboard.js"></script>
<script src="assets/js/select2.js"></script>
<script src="assets/js/file-upload.js"></script>
    <script src="assets/js/typeahead.js"></script>
<!-- End custom js for this page -->


<script>


    reg = document.getElementById("form-submit");
    firstn = document.getElementById("firstname");
    middn = document.getElementById("middelname");
    lastn = document.getElementById("lastname");
    un = document.getElementById("username");
    pass = document.getElementById("password");
    cpass = document.getElementById("cpassword");
    email = document.getElementById("email");
    mn = document.getElementById("mobile");
    add = document.getElementById("address");
    gn1 = document.getElementById("gender1");
    gn = document.getElementsByName("ugender");
    gn1 = gn[0];
    gn2 = gn[1];
 
    ln = document.getElementsByName("ulang[]");
    ln1 = ln[0];
    ln2 = ln[1];
    ln3 = ln[2];
    ln4 = ln[3];
    img = document.getElementById("image");


    fnerr = document.getElementById("firstnerr");
    nmExp = /^[a-zA-Z]{2,15}$/;
    unerr = document.getElementById("unerr");
    unExp = /^[a-zA-Z0-9]{5,15}$/;
    passerr =document.getElementById("passerr");
    passExp = /^[a-zA-Z0-9]$/;
    cpasserr =document.getElementById("cpasserr");
   
    emailerr =document.getElementById("emailerr");
    emailExp = /^[a-zA-Z]$/;


   
    moberr =document.getElementById("moberr");
    mnExp = /^[0-9]{10}$/;

    adderr =document.getElementById("adderr");
    addExp = /^[a-zA-Z]{10,40}$/;
    
    gnerr =document.getElementById("gnerr");
    lnerr =document.getElementById("lnerr");

    function getAlert() {
// ----------------------------------------------------------First Name - Mid Name - Last Name--------------------------------------------------------------------------
        if (firstn.value == "") {
            fnerr.innerHTML = "First Name Is Required";
            fnerr.style.color = "red";
            // return false;
        } else if (!nmExp.test(firstn.value)) {
            fnerr.innerHTML = "First Name must be 2 to 8 character only";
            fnerr.style.color = "red";
            // return false;
        } else if (middn.value == "") {
            fnerr.innerHTML = "Middel Name Is Required";
            fnerr.style.color = "red";
            // return false;
        } else if (!nmExp.test(middn.value)) {
            fnerr.innerHTML = "Middel Name must be 2 to 8 character only";
            fnerr.style.color = "red";
            // return false;
        } else if (lastn.value == "") {
            fnerr.innerHTML = "Last Name Is Required";
            fnerr.style.color = "red";
            // return false;
        } else if (!nmExp.test(lastn.value)) {
            fnerr.innerHTML = "Last Name must be 2 to 8 character only";
            fnerr.style.color = "red";
            // return false;
        } else {
            fnerr.innerHTML = "";
        }

// ----------------------------------------------------------User Name--------------------------------------------------------------------------

        if (un.value == "") {
            unerr.innerHTML = "UserName Is Required";
            unerr.style.color = "red";
            // return false;
        } 
        else if (!unExp.test(un.value)) {
            unerr.innerHTML = "UserName must be 5 to 10 character only";
            unerr.style.color = "red";
            // return false;
        }
         else {
            unerr.innerHTML = "";
        }
        
// --------------------------------------------------------Password--------------------------------------------------------------------------

        if (pass.value == "") {
            passerr.innerHTML = "Password Is Required";
            passerr.style.color = "red";
            // return false;
        }
        else {
            passerr.innerHTML = "";
        }

// -----------------------------------------------------Confirm Password--------------------------------------------------------------------------
        if (cpass.value == "") {
            cpasserr.innerHTML = "Confirm Password Is Required";
            cpasserr.style.color = "red";
            // return false;
        } 
        else if (cpass.value != pass.value) {
            cpasserr.innerHTML = "Confirm Paasword Dose Not Match";
            cpasserr.style.color = "red";
            // return false;
        } 
        else {
            cpasserr.innerHTML = "";
        }


// ----------------------------------------------------------email--------------------------------------------------------------------------
if (email.value == "") {
            emailerr.innerHTML = "Email Is Required";
            emailerr.style.color = "red";
            // return false;
        }
        else if (!emailExp.test(email.value)) {
            emailerr.innerHTML = "Enter Valid Email";
            emailerr.style.color = "red";
            // return false;
        }
        else {
            emailerr.innerHTML = "";
        }


// ----------------------------------------------------------Mobile--------------------------------------------------------------------------

        if (mn.value == "") {
            moberr.innerHTML = "Mobile Number Is Required";
            moberr.style.color = "red";
            // return false;
        } 
        else if (!mnExp.test(mn.value)) {
            moberr.innerHTML = "Enter Valid Mobile Number";
            moberr.style.color = "red";
            // return false;
        } 
        else {
            moberr.innerHTML = "";
        }

// ----------------------------------------------------------Address--------------------------------------------------------------------------

        if (add.value == "") {
            adderr.innerHTML = "Address Is Required";
            adderr.style.color = "red";
            // return false;
        }
        else if (!addExp.test(add.value)) {
            adderr.innerHTML = "Enter Valid Address";
            adderr.style.color = "red";
            // return false;
        } 
        else {
            adderr.innerHTML = "";
        }

// ----------------------------------------------------------Gender--------------------------------------------------------------------------

if (gn1.checked == false && gn2.checked == false) {
            gnerr.innerHTML = "Gender Is Required";
            gnerr.style.color = "red";
            // return false;
        }
        else {
            gnerr.innerHTML = "";
        }

// ----------------------------------------------------------Language--------------------------------------------------------------------------

if (ln1.checked == false && ln2.checked == false && ln3.checked == false && ln4.checked == false) {
            lnerr.innerHTML = "Language Is Required";
            lnerr.style.color = "red";
            // return false;
        }
        else {
            lnerr.innerHTML = "";
        }
// ----------------------------------------------------------Image--------------------------------------------------------------------------

if (img.value == "") {
            imgerr.innerHTML = "Image Is Required";
            imgerr.style.color = "red";
            return false;
        } else {
            imgerr.innerHTML = "";
        }


    }

    // console.log(firstn,firstn,lastn,un);
</script>
</body>

</html>