<?php
include("header.php");
?>
<div class="main-panel">
    <div class="content-wrapper">
        <div class="page-header">
            <h3 class="page-title"> Add User </h3>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Users</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Add Users</li>
                </ol>
            </nav>
        </div>
        <div class="row justify-content-center">
            <div class="col-md-6 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">User Registration Form</h4>
                        <p class="card-description"> Register here to connect with us </p>
                        <form method="post" enctype="multipart/form-data" onsubmit="return getAlert()">
                            <div class="row">
                                <div class="form-group col-sm-4">
                                    <label for="exampleInputUsername1">First Name</label>
                                    <input name="ufirtsname" type="text" class="form-control" id="firstname" placeholder="Enter Here">
                                    <b id="firstnerr"></b>
                                </div>
                                <div class="form-group col-sm-4">
                                    <label for="exampleInputUsername1">Middel Name</label>
                                    <input name="umiddelname" type="text" class="form-control" id="middelname" placeholder="Enter Here">
                                    <b id="firstnerr"></b>
                                </div>
                                <div class="form-group col-sm-4">
                                    <label for="exampleInputUsername1">Last Name</label>
                                    <input name="ulastname" type="text" class="form-control" id="lastname" placeholder="Enter Here">
                                    <b id="firstnerr"></b>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputUsername1">UserName</label>
                                    <input name="uusername" type="text" class="form-control" id="username" placeholder="Enter UserName">
                                    <b id="unerr"></b>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputUsername1">Password</label>
                                    <input name="upassword" type="text" class="form-control" id="password" placeholder="Enter Password">
                                    <b id="passerr"></b>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputUsername1">Enter Confirm Password</label>
                                    <input name="ucpassword" type="text" class="form-control" id="cpassword" placeholder="Enter Confirm Password">
                                    <b id="cpasserr"></b>
                                </div>

                                <div class="form-group">
                                    <label for="exampleInputUsername1">Enter Email</label>
                                    <input name="uemail" type="text" class="form-control" id="email" placeholder="Enter Email">
                                    <b id="emailerr"></b>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputUsername1">Enter Mobile Number</label>
                                    <input name="umobile" type="text" class="form-control" id="mobile" placeholder="Enter Email">
                                    <b id="moberr"></b>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputUsername1">Enter Address</label>
                                    <input name="uaddress" type="text" class="form-control" id="address" placeholder="Enter Address">
                                    <b id="adderr"></b>
                                </div>
                                <div class="form-group">
                                    <h5 class="card">Gender</h5>
                                    <div class="form-check">
                                        <label class="form-check-label">
                                            <input type="radio" class="form-check-input" name="ugender" id="gender1" value="Male">Male </label>
                                    </div>
                                    <div class="form-check">
                                        <label class="form-check-label">
                                            <input type="radio" class="form-check-input" name="ugender" id="gender2" value="Female">Female</label>
                                    </div>
                                    <b id="gnerr"></b>
                                </div>
                                <div class="form-group">
                                    <h4 class="card-title">Languages</h4>
                                    <div class="form-check">
                                        <label class="form-check-label">
                                            <input name="ulang[]" type="checkbox" class="form-check-input" id="lang1" value="English">English</label>
                                    </div>
                                    <div class="form-check">
                                        <label class="form-check-label">
                                            <input name="ulang[]" type="checkbox" class="form-check-input" id="lang2" value="Gujarat">Gujarat</label>
                                    </div>
                                    <div class="form-check">
                                        <label class="form-check-label">
                                            <input name="ulang[]" type="checkbox" class="form-check-input" id="lang3" value="Hindi">Hindi</label>
                                    </div>
                                    <div class="form-check">
                                        <label class="form-check-label">
                                            <input name="ulang[]" type="checkbox" class="form-check-input" id="lang4" value="Tamil">Tamil</label>
                                    </div>
                                    <b id="lnerr"></b>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputUsername1">Upload User Image</label>
                                    <input name="uimage" type="file" class="form-control" id="image" placeholder="Enter Product Image">
                                    <b id="imgerr"></b>
                                </div>
                                <button name="register" type="submit" class="btn btn-gradient-primary me-2" id="form-submit">Add User</button>
                                <button class="btn btn-light">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>


        </div>
    </div>
    <!-- content-wrapper ends -->
    <?php
    include("footer.php");
    ?>