<?php
include("header.php");
?>
<div class="main-panel">
    <div class="content-wrapper">
        <div class="page-header">
            <h3 class="page-title"> Manage Category </h3>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Category</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Manage Category</li>
                </ol>
            </nav>
        </div>
        <div class="row">
      <div class="col-12 grid-margin">
        <div class="card">
          <div class="card-body">
            <h4 class="card-title">categories</h4>
            <div class="table-responsive">
              <table class="table">
                <thead>
                  <tr>
                    <th> Id </th>
                    <th> Name </th>
                    <th> UserName </th>
                    <th> Password </th>
                    <th> Email </th>
                    <th> Mobile </th>
                    <th> Address </th>
                    <th> Gender </th>
                    <th> Languages </th>
                    <th> Image </th>
                    <th> Action </th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    
                  <td> WD-12345 </td>
                  <td> WD-12345 </td>
                  <td> WD-12345 </td>
                  <td> WD-12345 </td>
                  <td> WD-12345 </td>
                  <td> WD-12345 </td>
                  <td> WD-12345 </td>
                  <td> WD-12345 </td>
                  <td> WD-12345 </td>
                    <td>
                      <img src="assets/images/faces/face1.jpg" class="me-2" alt="image">
                    </td>
                    <td>
                      <a href="">view</a>
                      <a href="">edit</a>
                      <a href="">delete</a>
                    </td>
                  </tr>
                  
                  
                  <tr>
                    
                  <td> WD-12345 </td>
                  <td> WD-12345 </td>
                  <td> WD-12345 </td>
                  <td> WD-12345 </td>
                  <td> WD-12345 </td>
                  <td> WD-12345 </td>
                  <td> WD-12345 </td>
                  <td> WD-12345 </td>
                  <td> WD-12345 </td>
                    <td>
                      <img src="assets/images/faces/face1.jpg" class="me-2" alt="image">
                    </td>
                    <td>
                      <a href="">view</a>
                      <a href="">edit</a>
                      <a href="">delete</a>
                    </td>
                  </tr>


                  <tr>
                    
                  <td> WD-12345 </td>
                  <td> WD-12345 </td>
                  <td> WD-12345 </td>
                  <td> WD-12345 </td>
                  <td> WD-12345 </td>
                  <td> WD-12345 </td>
                  <td> WD-12345 </td>
                  <td> WD-12345 </td>
                  <td> WD-12345 </td>
                    <td>
                      <img src="assets/images/faces/face1.jpg" class="me-2" alt="image">
                    </td>
                    <td>
                      <a href="">view</a>
                      <a href="">edit</a>
                      <a href="">delete</a>
                    </td>
                  </tr>


                  
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
    </div>
    <!-- content-wrapper ends -->
    <?php
    include("footer.php");
    ?>