<?php
include("model.php");


class controller extends model
{
    function __construct()
    {
        session_start();
        model::__construct();
        $removeExtention = $_SERVER['PATH_INFO'];
        switch ($removeExtention) {
            case '/index':
                if(isset($_POST['alogin']))
                {
                $ausername = $_POST['ausername'];
                $apassword = $_POST['apassword'];
                
                $where = array("a_username"=> $ausername,"a_password"=>$apassword);
                $fetch_where = $this->select_where("admin",$where);

                $dbausername = $fetch_where->a_username;
                $dbapassword = $fetch_where->a_password;

                $_SESSION['adminusername'] = $dbausername;   

                if($dbausername == $ausername && $dbapassword == $apassword)
                {
                    echo "<script>
                    alert('Wlecome Admin')
                    window.location.href = 'dashboard'</script>";
                }
                else
                {
                    
                    echo "<script>
                    alert('Invalide Username Or Password')</script>";
                }

                if(isset($_POST['keepmelogin']))
                {
                    setcookie('adminusername',$ausername,time()+30);
                    setcookie('adminpassword',$apassword,time()+30);
                }

                }
                include "index.php";
                break;

            case "/logout":
                unset($_SESSION['adminusername']);
                header("location:index");
                break ;
            case '/dashboard':
                include "dashboard.php";
                break;
            case '/add-user':
                if (isset($_POST['register'])) {
                    $ufirstname = $_POST['ufirtsname'];
                    $umiddelname = $_POST['umiddelname'];
                    $ulastname = $_POST['ulastname'];
                    $uusername = $_POST['uusername'];
                    $upassword = $_POST['upassword'];
                    $uemail = $_POST['uemail'];
                    $umobile = $_POST['umobile'];
                    $uaddress = $_POST['uaddress'];
                    $ugender = $_POST['ugender'];

                    $ulang = "";
                    $ulanguage = $_POST['ulang'];
                    foreach ($ulanguage as $ulang) {
                        $ulang = implode(",", $ulanguage);
                    }

                    $uimage = $_FILES['uimage']['name'];
                    $duplicateimage = $_FILES['uimage']['tmp_name'];
                    $path = "../user/assets/user_images/" . $uimage;
                    move_uploaded_file($duplicateimage, $path);

                    $user_data = array('u_firstname' => $ufirstname, 'u_middlename' => $umiddelname, 'u_lastname' => $ulastname, 'u_username' => $uusername, 'u_password' => $upassword, 'u_email' => $uemail, 'u_mobile' => $umobile, 'u_address' => $uaddress, 'u_gender' => $ugender, 'u_languages' => $ulang, 'u_image' => $uimage);

                    $this->insert("users", $user_data);
                }

                include "add-user.php";
                break;
                
            case '/manage-user':
                $user_arr = $this->select('users');

                $singleid = $_GET['singleid'];
                $where = array("u_id" => $singleid);
                $fetch_where = $this->select_where('users', $where);
                include "manage-user.php";
                break;

            case '/edit-user':
                $eid = $_GET['editid'];
                $where = array("u_id" => $eid);
                $fetch_where = $this->select_where('users', $where);


                if (isset($_POST['Update_user'])) {
                    $ufirstname = $_POST['ufirtsname'];
                    $umiddelname = $_POST['umiddelname'];
                    $ulastname = $_POST['ulastname'];
                    $uusername = $_POST['uusername'];
                    $upassword = $_POST['upassword'];
                    $uemail = $_POST['uemail'];
                    $umobile = $_POST['umobile'];
                    $uaddress = $_POST['uaddress'];
                    $ugender = $_POST['ugender'];

                    $ulang = "";
                    $ulanguage = $_POST['ulang'];
                    foreach ($ulanguage as $ulang) {
                        $ulang = implode(",", $ulanguage);
                    }

                    $uimage = $_FILES['uimage']['name'];
                    $duplicateimage = $_FILES['uimage']['tmp_name'];
                    $path = "../user/assets/user_images/" . $uimage;
                    move_uploaded_file($duplicateimage, $path);

                    if ($_FILES['uimage']['size'] > 0) {

                        $data = array('u_firstname' => $ufirstname, 'u_middlename' => $umiddelname, 'u_lastname' => $ulastname, 'u_username' => $uusername, 'u_password' => $upassword, 'u_email' => $uemail, 'u_mobile' => $umobile, 'u_address' => $uaddress, 'u_gender' => $ugender, 'u_languages' => $ulang, 'u_image' => $uimage);
                    } else {
                        $data = array('u_firstname' => $ufirstname, 'u_middlename' => $umiddelname, 'u_lastname' => $ulastname, 'u_username' => $uusername, 'u_password' => $upassword, 'u_email' => $uemail, 'u_mobile' => $umobile, 'u_address' => $uaddress, 'u_gender' => $ugender, 'u_languages' => $ulang);
                    }
                    $update_data =  $this->update("users", $data, $where);
                }

                include "edit-user.php";
                break;


            case "/delete-user":
                $delid = $_GET['delid'];
                $where= array('u_id'=>$delid);
                $delete = $this->delete_where('users',$where);
                


                if($delete)
                {
                    header("location:manage-user");
                }
                break;


            case '/add-category':
                include "add-category.php";
                break;
            case '/manage-category':
                include "manage-category.php";
                break;
            case '/add-subcategory':
                include "add-subcategory.php";
                break;
            case '/manage-subcategory':
                include "manage-subcategory.php";
                break;
            case '/add-product':
                include "add-product.php";
                break;
            case '/manage-product':
                include "manage-product.php";
                break;
            case '/manage-orders':
                include "manage-orders.php";
                break;
            case '/manage-feedback':
                include "manage-feedback.php";
                break;
            case '/single-user':
                $singleid = $_GET['singleid'];
                $where = array("u_id" => $singleid);
                $fetch_where = $this->select_where('users', $where);
                // include "single-user.php";
                break;
        }
    }
}

$obj = new controller();
