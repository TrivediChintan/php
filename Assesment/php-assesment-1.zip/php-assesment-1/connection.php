<?php

$con = mysqli_connect('localhost','root','','assesment');

if($con)
{
    // echo "Database Connected<br>";
}