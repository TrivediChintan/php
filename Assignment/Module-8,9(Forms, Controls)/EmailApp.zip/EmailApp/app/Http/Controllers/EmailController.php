<?php

namespace App\Http\Controllers;

use App\Mail\EmailSending;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class EmailController extends Controller
{
    function sendMail(Request $request)
    {
        if($request->file('file'))
        {
            $file = $request->file;
            $attach = $file->getClientOriginalName();
            $file->move(public_path("uploads/"),$attach);
        }
        else
        {
            $attach = "null";
        }

        $to = $request->email;
        $subject = $request->subject;
        $message = $request->message;
        $attach = $request->attach;

       $dd=  Mail::to($to)->send(new EmailSending($subject,$message,$attach));
    dd($dd);
        
    }
}
