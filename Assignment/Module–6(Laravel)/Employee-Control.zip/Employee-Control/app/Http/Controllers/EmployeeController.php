<?php

namespace App\Http\Controllers;

use App\Models\Employee;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;

class EmployeeController extends Controller
{
       public function index()
    {
        $std = Employee::all();
        return view('employees.index',compact('std'));
    }

    public function create()
    {
        return view('employees.create');
    }

   
    public function store(Request $request)
    {
        $std = new Employee();

        if($request->file('image'))
        {
            $file = $request->image;
            $filename = $file->getClientOriginalName();
            $file->move(public_path("uploads/"),$filename);
        }

        $std->name = $request->name;
        $std->age = $request->age;
        $std->image = $filename;
        $std->address = $request->address;

        $std->save();
        return redirect()->route('employees.index');
    }

   
    public function edit($id)
    {
        $student = Employee::find($id);
        return view('employees.edit',compact('student'));
    }

   
    public function update(Request $request, $id)
    {
        $std = Employee::find($id);

        if($request->file('image'))
        {
            $file = $request->image;
            $filename = $file->getClientOriginalName();
            $file->move(public_path("uploads/"),$filename);
        }
        else
        {
            $filename = $std->image;
        }

        $std->name = $request->name;
        $std->age = $request->age;
        $std->image = $filename;
        $std->address = $request->address;

        $std->update();
        return redirect()->route('employees.index');
    }

    
    public function destroy($id)
    {
        $std = Employee::find($id);
        File::delete(public_path("uploads/$std->image"));
        $std->delete();
        return redirect()->route('employees');
    }
}
