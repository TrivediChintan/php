<?php

namespace App\Http\Controllers;

use App\Models\Admin;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    function index(request $request)
    {
        $admin = new Admin();

        $email = $request->email;
        $data = $admin->select('email')->where('email','=',$email)->first();

        return response()->json($data);

        
    }

    function show()
    {
        return view('admin.home');
    }
}
