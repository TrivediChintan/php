<?php
  $links = array(
    'js' => 'resourceslib/waypoints/waypoints.min.js'
  );
?>
