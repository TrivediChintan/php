@extends('user.master')
@section('data')


    <!-- Page Header Start -->
    <div class="container-fluid bg-dark bg-img p-5 mb-5">
        <div class="row">
            <div class="col-12 text-center">
                <h1 class="display-4 text-uppercase text-white">Master Chefs</h1>
                <a href="">Home</a>
                <i class="far fa-square text-primary px-2"></i>
                <a href="">Master Chefs</a>
            </div>
        </div>
    </div>
    <!-- Page Header End -->


    @endsection
