<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</head>
<body>

    <div class="container pt-5">
        <div class="row justify-content-center pt-5">
            <div class="col-xl-9">
                <div>
                    <h3>Users Details</h3>
                </div>
                <table class="table">
                    <thead>
                        <tr>
                        <th scope="col">ID</th>
                        <th scope="col">NAME</th>
                        <th scope="col">EMAIL</th>
                        <th scope="col">PASSWORD</th>
                        <th scope="col">PHONE</th>
                        <th>ACTION</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <td><?php echo e($u->id); ?></td>
                        <th><?php echo e($u->name); ?></th>
                        <td><?php echo e($u->email); ?></td>
                        <td><?php echo e($u->password); ?></td>
                        <td><?php echo e($u->phone); ?></td>
                        <td>
                            <a href="<?php echo e(URL::to('edit',$u->id)); ?>" class="btn btn-primary">EDIT</a>

                            <form action="<?php echo e(URL::to('delete',$u->id)); ?>" method="post" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                            <button type="submit" class="btn btn-danger">DELETE</button></form>
                        </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <a href="create" class="btn btn-primary">Add New</a>
            </div>
        </div>
    </div>
    
</body>
</html><?php /**PATH C:\xampp\htdocs\LARAVEL\CRUD_PRACTICE\example-app\resources\views/users/index.blade.php ENDPATH**/ ?>